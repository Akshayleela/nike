let express = require('express');
let app = express();
let port = 9500;
let mongo =require('mongodb');
let MongoClient = mongo.MongoClient;
let mongoUrl = "mongodb://localhost:27017";
let db;

app.get('/a',(req, res) => {                      // "/" is used for default routes
    res.send('<h1>Welcome! to chennai express</h1>')
})

app.get('/categories',(req, res) => {
    db.collection('categories').find().toArray((err,result) => {
        if(err) throw err;
        res.send(result)
    })
})


///// Connect with mongodb
MongoClient.connect(mongoUrl,{useNewUrlParser:true},(err,client)=>{
    err ? console.log('Error while connecting') : db=client.db('sepintern')
    app.listen(port,()=>{
        console.log(`server is running on port ${port}`)
    })
})